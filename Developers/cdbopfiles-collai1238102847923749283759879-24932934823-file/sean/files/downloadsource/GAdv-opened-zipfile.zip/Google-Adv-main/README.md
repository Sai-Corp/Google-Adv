<h1><p><a href="https://sai-corp.github.io/Google-Adv/">Google ADV</a></p> </h1>
<h4>Enhanced google. Enhanced search.</h4>
<p>Google ADV makes searching the web with google easier. Instead of you searching exact results, our SAS (Search Analysis Server) connects to our psc (Precise Search Catalog) which automatically detects things closer to what you have typed so far in a dropdown menu.</p>
<p>Google ADV also blocks any advertisements coming in your way. We have also set a new google logo to replace the logo that has spent more than 2 years staying.</p>
<p>Latest updates: Google ADV now has a Developer Portal!</p>
